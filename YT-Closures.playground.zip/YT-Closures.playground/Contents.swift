import UIKit

//MARK: - Declaración de closures, asignación a variables, reciben parámetros, devuelven objetos
let myClosure = {
    print("Hola")
}

myClosure()

let sayHello = { (name: String) in
    print("Hola, \(name)")
}

sayHello("Abner")

func sayHello(name: String) {
    print("Hola, \(name)")
}

sayHello(name: "Abner")

let giveMeSomething = { () -> Int in
    return 18
}

print(2 + giveMeSomething())

let anotherClosure: () -> () = {
    print("Un closure más")
}


let myView: UIView = {
    let view = UIView()
    view.backgroundColor = .yellow
    return view
}()

//MARK: - Diferencias entre closures y funciones; son lo mismo (solo por el nombre)
func createView() -> UIView {
    return UIView()
}

let customView = createView()

//MARK: - Función que manipula un arreglo primero ordenándolo
func sortArray(_ array: [Int]) -> [Int] {
    return array.sorted()
}

func manipulateArray(_ array: [Int], sortFunction: ([Int]) -> [Int]) {
    // ordernar el array
    var sortedArray = sortFunction(array)
    
    // array manipulation
    print(sortedArray)
}

manipulateArray([4, 3, 6, 2, 7], sortFunction: sortArray)

manipulateArray([4,3,7,9,1,2]) {
    $0.sorted(by: { $0 < $1 })
}

//MARK: - Ejemplos de closures en la programación diaria
class ViewController: UIViewController {
    
    let myView: UIView = {
        let view = UIView()
        view.backgroundColor = .systemYellow
        view.alpha = 0
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.async {
            self.asyncFunc()
        }
    }
    
    func asyncFunc() {
        
    }
    
    func animate() {
        UIView.animate(withDuration: 2.0) {
            self.view.alpha = 1
        }
    }
    
    func delayAnimation() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.animate()
        }
    }
    
}

//MARK: - Los closures capturan valores
var myNumber = 0

let incClosure = {
    myNumber += 1
}

incClosure()
print(myNumber)

var image = UIImage(systemName: "photo")

let changeImageClosure = {
    image = UIImage(systemName: "add")
}


// MARK: - Escaping Closures
class CustomButton: UIButton {
    
    var actionClosure: (() -> ())?
    
    func addTarget(_ actionClosure: @escaping () -> ()) {
        self.actionClosure = actionClosure
        addTarget(self, action: #selector(execActionClosure), for: .touchUpInside)
    }
    
    @objc private func execActionClosure() {
        actionClosure?()
    }
    
}

let customButton = CustomButton()

customButton.addTarget {
    print("Holaaaa")
}
